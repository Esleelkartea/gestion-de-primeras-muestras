<?php
$img = $_POST['src'];
echo "<script>document.write('<img src=\"$img\">')</script>\n";
?>