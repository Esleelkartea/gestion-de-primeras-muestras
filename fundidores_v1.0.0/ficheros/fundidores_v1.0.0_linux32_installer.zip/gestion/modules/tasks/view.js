// $Id: view.js,v 1.3 2006/03/27 15:30:24 Attest sw-libre@attest.es Exp $
// $Id: view.js,v 1.2 2005/03/19 05:58:52 ajdonnison Exp $
// Task view support routines.
function popEmailContacts() {
	
	var email_others = document.getElementById('email_others');
	window.open(
	  './index.php?m=public&a=contact_selector&dialog=1&call_back=setEmailContacts&selected_contacts_id='
		+ email_others.value, 'contacts','height=600,width=400,resizable,scrollbars=yes');
}

function setEmailContacts(contact_id_string) {
	if (! contact_id_string)
		contact_id_string = "";
	var email_others = document.getElementById('email_others');
	email_others.value = contact_id_string;
}

function updateEmailContacts() {
	
	var email_others = document.getElementById('email_others');
	var task_emails = document.getElementById('email_task_list');
	var proj_emails = document.getElementById('email_project_list');
	var dep_list = document.getElementById('email_dep_list');
	
	var do_task_emails = document.getElementById('email_task_contacts');
	var do_proj_emails = document.getElementById('email_project_contacts');		
	var	do_dep = document.getElementById('email_dep_ch');

	
	// Build array out of list of contact ids.
	var email_list = email_others.value.split(',');
	
	if (do_task_emails.checked) {
		var telist = task_emails.value.split(',');
		var full_list = email_list.concat(telist);
		email_list = full_list;
		do_task_emails.checked = false;
	} else task_emails.value='';

	if (do_proj_emails.checked) {
		
		var prlist = proj_emails.value.split(',');
		var full_proj = email_list.concat(prlist);
		email_list = full_proj;
		do_proj_emails.checked = false;
	} else proj_emails.value='';
	
	if (do_dep.checked) {
		
		var dep = dep_list.value.split(',');
		var todo = email_list.concat(dep);
		email_list = todo;
		do_dep.checked = false;
	} else dep_list.value='';
	
	// Now do a reduction
	email_list.sort();
	var output_array = new Array();
	var last_elem = -1;
	for (var i = 0; i < email_list.length; i++) {
		if (email_list[i] == last_elem) {
			continue;
		}
		last_elem = email_list[i];
		output_array.push(email_list[i]);
	}
	
	document.getElementById('email_others').value = output_array.join();
	//editFrm.submit();
}

function emailNumericCompare(a, b) {
	return a - b;
}
