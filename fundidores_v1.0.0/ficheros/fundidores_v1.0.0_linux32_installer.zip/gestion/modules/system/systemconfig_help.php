<?php  // $Id: systemconfig_help.php,v 1.2 2005/03/02 06:34:53 ajdonnison Exp $
$cn = $_REQUEST['cn'];
?>
<table cellspacing="0" cellpadding="3" border="0" class="std" width="100%" align="center">
	<tr>
 		<td align="left" colspan="2"><?php echo $AppUI->_($cn.'_tooltip'); ?></td>
	</tr>
</table>
