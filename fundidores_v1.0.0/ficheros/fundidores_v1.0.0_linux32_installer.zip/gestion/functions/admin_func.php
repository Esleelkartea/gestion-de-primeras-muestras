<?php
// user types
$utypes = array(
// DEFAULT USER (nothing special)
	0 => '',
// DO NOT CHANGE ADMINISTRATOR INDEX !
	1 => 'Administrator',
// you can modify the terms below to suit your organisation
	2 => 'CEO',
	3 => 'Director',
	4 => 'Branch Manager',
	5 => 'Manager',
	6 => 'Supervisor',
	7 => 'Employee'
);

##
##	NOTE: the user_type field in the users table must be changed to a TINYINT
##
?>